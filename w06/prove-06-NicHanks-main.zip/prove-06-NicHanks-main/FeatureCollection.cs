namespace prove_06;

public class FeatureCollection {
    // Todo Problem 5 - ADD YOUR CODE HERE
    // Create additional classes as necessary
}