﻿namespace MySet;

public class MySetList
{

    public MySetList()
    {
        
    }

    public void Add(int value)
    {
        
    }


    public void Remove(int value)
    {
        
    }
    
    public bool Contains(int value)
    {
        return false;
    }
    
    public int Size()
    {
        return 0;
    }

}