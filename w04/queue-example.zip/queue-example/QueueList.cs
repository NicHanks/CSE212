﻿namespace queue_example;

// Implement a queue in using a List

public class QueueList
{
    public QueueList()
    {
    }
    
    public int Size()
    {
        return(-1);
    }
    
    public void Enqueue(int value)
    {
    }
    
    public int Dequeue()
    {
        return(-1);
    }

    public int Peek()
    {
        return(-1);
    }
    
}